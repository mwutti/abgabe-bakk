Im Ordner conect-app befindet sich der Sourcecode der Android-App
Im Ordner ConnectCSVToDB befindet sich das Script zur Erstellung der DB-Inserts auf Basis der .csv-Dateien
Im Ordner MapAreaTool befindet sich der Source Code des Programms zur Bestimmung der Koordinaten
